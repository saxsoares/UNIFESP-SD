#include "square.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <strings.h>

square_out * squareproc_1_svc(square_in *in, struct svc_req *rqstp){
	static square_out out;
	out.res = in->arg * in->arg;
	return(&out);
}

req_out * reqproc_1_svc (req_in *reqin, struct svc_req *rqstp){
	static req_out out;
	out.flag = 'A';
	out.a_int = 11;
	out.other_int = 22;
	return(&out);
}
